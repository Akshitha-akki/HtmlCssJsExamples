function add()
{
    var n1 = parseFloat(document.getElementById('n1').value);
    var n2 = parseFloat(document.getElementById('n2').value);
    if( isNaN(n1) && isNaN(n2) )//not a number - NaN
    {
    alert( " Enter valid number " );
    return;
    }
    document.getElementById("answer").innerHTML =calcadd(n1,n2);
    function calcadd()
    {
        return ("Add : "+(n1+n2));
    }
}
function sub()
{
    var n1 = parseFloat(document.getElementById('n1').value);
    var n2 = parseFloat(document.getElementById('n2').value);
    if( isNaN(n1) && isNaN(n2) )//not a number - NaN
    {
    alert( " Enter valid number " );
    return;
    }
    var op = (n1-n2);
    document.getElementById("answer").innerHTML = op;
    // function calcsub()
    // {
    //     return ("sub : "+(n1-n2));
    // }
}