function sayHello() {
    alert("Hello");
}
document.getElementById("bt1").onclick=sayHello;